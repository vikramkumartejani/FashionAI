import React from 'react';
import './LoadingSpinner.css'

const LoadingSpinner = () => {
  return (
    <div className="loading-spinner">
     <p> The model is Predicting</p>
    </div>
  );
};

export default LoadingSpinner;
